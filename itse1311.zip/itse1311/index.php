<?php

$myVar  = "Jennifer Wellmann";

if $myVar == "Jennifer Wellmann" {

    echo $myVar;

}
else {
    echo "Not Jennifer Wellmann";
}



?>