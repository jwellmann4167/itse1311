function chckName() {
  document.write("<p>My First Function</p>");
}
