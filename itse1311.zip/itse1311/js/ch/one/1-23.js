//alert("Hello World!");

console.log("Hello Chapter 2!");
