console.clear();

document.write("Hello Error");

/*Types of Errors and Strategies

// bug
// syntax errors - unrecognizes code
// run-time error - unexecutable code, like a non-existent function
// logic error - when undesired output is delivered
// tracing errors with window.alert
// commenting out
//isolating code
// Breakpoints
// Handling Exceptions and Errors (bullet proofing)
// Try, Throw, Catch, Finally

*/

//let if = "Jennifer Wellmann"; // syntax error example because the word "if" is a reserved word

//console.log(if);
