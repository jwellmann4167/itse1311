console.clear();

let myFirstNumber = 3;
let mySecondNumber = 7;

if (myFirstNumber === 4) {
  //
  console.log("This is zero");
} else if (mySecondNumber === 5) {
  //
  console.log("This is a two");
} else if (myFirstNumber === 0 || mySecondNumber === 2) {
  //
  console.log("Either a number was zero or two");
}
//
else if (myFirstNumber === 3 && mySecondNumber === 7) {
  //
  console.log("Either a number was zero or two");
  alert("Payment Recieved");
} else {
  //
  console.log("Not any of the numbers");
}
