console.clear();

//let name = [value1, value2, value3];
//let name = ["string", 1, false]; //you can have different values with different data types

let colors = [];

colors[4] = "Yellow";

console.log(colors);
console.log(colors.length);

/* LOOPS

while - it can run without going into the loop even once
do/while - it runs inside of the loop at least once
for - it allows you to define a variable within the loop statement

*/

var fruits = [
  "apples",
  "oranges",
  "bananas",
  "strawberries",
  "watermelon",
  "mangoes",
  "peaches"
];

console.log(fruits[4]);

for (var myCounter = 0; myCounter < fruits.length; myCounter++) {
  console.log(
    "my fruits loop is running at number " +
      myCounter +
      " which is " +
      fruits[myCounter]
  );
}

/*
for (var myCounter = 0; myCounter < colors.length; myCounter++) {
  console.log("my loop is running at " + myCounter);
}
*/

/*example of do/while loop
var myCounter = 1;
var myStop = 7;

do {
  console.log("my loop is running at " + myCounter);
  myCounter++;
} while (myCounter < colors.length);
*/

/*// example of while loop
var myCounter = 0;
var myStop = colors.length;

while (myCounter < myStop) {
  console.log("my loop is running at " + myCounter);

  myCounter++;
}
*/
/*
var myCounter = 1;
var myStop = 10;

while (myCounter < myStop) {
  console.log("my loop is running at " + myCounter);

  myCounter++;
}
*/
