console.clear();

/*

// getElementById
// getElementsByClassName
// getElementsByName
// getElementsByTagName
// querySelectorAll

*/

//let firstName = document.getElementById("firstName");
//console.log(firstName.value);

//let timeOfDay = document.getElementById("timeOfDayMorning");
//console.log(timeOfDay.value);

//let timeOfDayField = document.getElementsByName("timeOfDay");
//console.log(timeOfDayField);

//let timeOfDayField = document.getElementsByTagName("input")[0];
//console.log(timeOfDayField);

//let firstName = document.querySelector("#firstName");
//console.log(firstName.value);

//let timeOfDayField = document.querySelector("#timeOfDay");
//console.log(timeOfDayField.value);

//let timeOfDayField = document.querySelectorAll(".timeOfDay")[0];
let timeOfDayField = document.querySelectorAll(".timeOfDay");

//console.log("The number of checkboxes are " + timeOfDayField.length);

let btn = document.getElementById("btn");
btn.addEventListener("click", chkTimeOfDay);

function chkTimeOfDay() {
  let timeOfDayFieldChecked = document.querySelectorAll(".timeOfDay:checked");

  //for (var myCounter = 0; myCounter < timeOfDayField.length; myCounter++) {
  for (
    var myCounter = 0;
    myCounter < timeOfDayFieldChecked.length;
    myCounter++
  ) {
    //console.log("test loop" + myCounter);
    //console.log("The Time of Day is " + myCounter);
    console.log("The Time of Day is " + timeOfDayFieldChecked[myCounter].value);
  }

  if (myCounter < 1) {
    alert("At least one checkbox has to be checked in the Time of Day field");
    return false;
  }

  //alert("test");
}
