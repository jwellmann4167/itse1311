var fName = document.getElementById("firstName");

//var fName = "Jennifer Wellmann-4";
/*
let myNumber = 1;

if (myNumber === 1) {
  let fName = "Jennifer Wellmann-4";
  console.log(fName);
}
*/
function chckName() {
  document.write("<p>My First Function</p>");
}
