// A $( document ).ready() block.
$(document).ready(function () {
  console.log("ready!");

  $(document).on("click", "#btn", makeRed);

  function makeRed() {
    $("#myDivThree").css("color", "red");
  }
});
