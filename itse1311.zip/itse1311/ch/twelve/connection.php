<?php

/**/
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


$rightNow = date("n/j/Y G:i");

//my CSS Code;
$yugkjhyfjyfkyt = "aXRzZTEzMTFhZG1pbg==";
$grghdrhsh = "cm9vdAo=";
$hfhgsrtfjhthj = "IWFiYzEyMzQ1Ng==";


$conn = new mysqli(base64_decode($yugkjhyfjyfkyt), base64_decode($grghdrhsh), base64_decode($hfhgsrtfjhthj), "itse1311");

//Create Connection
if ($conn->connect_error) {
   die("Connection Failed: " . $conn->connect_error);
}else {
    echo "Connection Successful";
}


//!abc123456
?>